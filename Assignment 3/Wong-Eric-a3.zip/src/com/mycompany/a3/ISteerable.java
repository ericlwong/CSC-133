/* Eric Wong
 * CSC 133
 * Assignment 3
 */

package com.mycompany.a3;

public interface ISteerable {
	public void steerLeft();
	public void steerRight();
}
