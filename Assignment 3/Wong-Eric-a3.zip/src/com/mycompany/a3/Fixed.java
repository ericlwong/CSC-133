/* Eric Wong
 * CSC 133
 * Assignment 3
 */

package com.mycompany.a3;

public abstract class Fixed extends GameObject implements ISelectable {
	
	// Constructor for a fixed game object
	public Fixed() { }
	
	public void setLocation() { }
}
